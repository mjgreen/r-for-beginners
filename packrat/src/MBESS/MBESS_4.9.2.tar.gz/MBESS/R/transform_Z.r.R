transform_Z.r <- function(Z)
{
return((exp(2*Z)-1)/(exp(2*Z)+1))
}  