#' @export
#' @importFrom insight is_empty_object
insight::is_empty_object

#' @export
#' @importFrom insight object_has_names
insight::object_has_names

#' @export
#' @importFrom insight object_has_rownames
insight::object_has_rownames

#' @export
#' @importFrom insight compact_list
insight::compact_list

#' @export
#' @importFrom insight compact_character
insight::compact_character
