# ranktransform works with data frames

    Code
      ranktransform(BOD)
    Output
        Time demand
      1    1      1
      2    2      2
      3    3      5
      4    4      4
      5    5      3
      6    6      6

