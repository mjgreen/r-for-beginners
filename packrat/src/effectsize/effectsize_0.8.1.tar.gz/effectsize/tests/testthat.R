library(testthat)
library(effectsize)

test_check("effectsize")
